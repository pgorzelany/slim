#!/bin/sh
set -eu
cd /Users/mlody/Projects/SLIM
verify_dir=$(mktemp -d /tmp/slim-verify-resumed.XXXXXX)
trap 'rm -rf "$verify_dir"' EXIT HUP INT TERM
clang -std=c11 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer \
  -Wall -Wextra -Werror -I runtime \
  bootstrap/slimc-seed.c runtime/slim_rt.c -o "$verify_dir/slimc-seed-sanitized"
sh scripts/verify-places.sh "$verify_dir/slimc-seed-sanitized"
sh scripts/verify-parsing.sh "$verify_dir/slimc-seed-sanitized"
sh scripts/verify-integers.sh build/toolchain/slimc full

"$verify_dir/slimc-seed-sanitized" session conformance/projects/basic/slim.project \
  conformance/projects/basic/slim.project > "$verify_dir/identity-session.out"
identity_fault_at=1
identity_faults=0
while test "$identity_fault_at" -le 128; do
  if SLIM_ALLOC_FAIL_AT="$identity_fault_at" "$verify_dir/slimc-seed-sanitized" \
    session conformance/projects/basic/slim.project conformance/projects/basic/slim.project \
    > "$verify_dir/identity-fault.out" 2> "$verify_dir/identity-fault.err"; then
    # Ordinals beyond this input's allocations must preserve ordinary output.
    cmp "$verify_dir/identity-session.out" "$verify_dir/identity-fault.out"
    test ! -s "$verify_dir/identity-fault.err"
  else
    identity_fault_status=$?
    test "$identity_fault_status" -eq 71
    test ! -s "$verify_dir/identity-fault.out"
    test "$(cat "$verify_dir/identity-fault.err")" = "SLIM allocation failure: exhausted at allocation $identity_fault_at"
    identity_faults=$((identity_faults + 1))
  fi
  identity_fault_at=$((identity_fault_at + 1))
done
test "$identity_faults" -gt 0
echo "verification: $identity_faults source-index allocation failures checked in 128 ordinals"

if SLIM_ALLOC_FAIL_AT=1 build/toolchain/slimc check examples/hello.slim \
  >"$verify_dir/compiler-fault.out" 2>"$verify_dir/compiler-fault.err"; then
  echo "verification: compiler allocation failure unexpectedly succeeded" >&2
  exit 1
else
  compiler_fault_status=$?
fi
test "$compiler_fault_status" -eq 71
test ! -s "$verify_dir/compiler-fault.out"
test "$(cat "$verify_dir/compiler-fault.err")" = "SLIM allocation failure: exhausted at allocation 1"

# The sieve challenge covers Boolean vector literals, vector mutation, and
# punctuation-bearing identifiers in one production build/run path.
./slimc build benchmarks/challenges/sieve/program.slim -o "$verify_dir/sieve"
test "$("$verify_dir/sieve")" = "78498"

./slimc emit-c examples/vector_sum.slim -o "$verify_dir/program.c"
./slimc runtime "$verify_dir"
clang -std=c11 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer \
  -Wall -Wextra -Werror -I "$verify_dir" \
  "$verify_dir/program.c" "$verify_dir/slim_rt.c" -o "$verify_dir/program"
test "$("$verify_dir/program")" = "4950"
for fault_at in 1 2 3 4 5 6; do
  if SLIM_ALLOC_FAIL_AT="$fault_at" "$verify_dir/program" >"$verify_dir/fault.out" 2>"$verify_dir/fault.err"; then
    echo "verification: injected allocation failure $fault_at unexpectedly succeeded" >&2
    exit 1
  else
    fault_status=$?
  fi
  test "$fault_status" -eq 71
  test ! -s "$verify_dir/fault.out"
  test "$(cat "$verify_dir/fault.err")" = "SLIM allocation failure: exhausted at allocation $fault_at"
done

echo "verification: remaining stages passed (resumed suffix only)"
